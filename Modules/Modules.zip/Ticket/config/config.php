<?php

return [
    'name' => 'Ticket',
];
