<?php

return [
    'name' => 'PortfolioCategory',
];
